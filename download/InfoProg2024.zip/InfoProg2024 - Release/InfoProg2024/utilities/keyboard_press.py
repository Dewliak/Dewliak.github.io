class Keyboard:
    """
    A billenytű lenyomásokat menti
    """
    UP_PRESSED = False
    DOWN_PRESSED = False
    LEFT_PRESSED = False
    RIGHT_PRESSED = False
    SPACE_PRESSED = False
    ENTER_PRESSED = False
    BACKSPACE_PRESSED = False

    S_PRESSED = False