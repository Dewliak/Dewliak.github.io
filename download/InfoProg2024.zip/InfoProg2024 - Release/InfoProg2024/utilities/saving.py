import json
import pprint

from InfoProg2024.utilities.settings.settings import SAVE_FILE_PATH

def save_game(controller, scoreboard) -> None:
    """
    Elmenti a játékot JSON formában
    """
    data = {'controller': controller.get_data_to_save(),
            'scoreboard': scoreboard.get_data_to_save()}
    pprint.pprint(data)
    with open(SAVE_FILE_PATH, "w") as f:
        json.dump(data, f)

