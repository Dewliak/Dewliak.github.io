"""
A kocka entitások alapbeállításai
"""

START_X = 70  # Első kocka x koordinátája
FIRST_ROW_Y = 105  # Első sor magassága
SECOND_ROW_Y = 368  # Második sor magasság
DISTANCE_BETWEEN_DICES = 115 # Két kocka közötti távolság