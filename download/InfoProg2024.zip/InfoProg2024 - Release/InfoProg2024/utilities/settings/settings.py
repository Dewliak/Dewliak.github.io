"""
Játék beállításait találjuk itt
"""

# GAME SETTINGS
WIDTH = 1200
HEIGHT = 600
KOMBO_SZAM = 9

SAVE_FILE_PATH = "InfoProg2024/saving.json"
HIGHSCORE_FILE_PATH = "InfoProg2024/high_scores.csv"


