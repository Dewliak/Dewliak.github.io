
from InfoProg2024.modulok.dobas_modul import DobasData, DobasErtekelo

if __name__ == "__main__":
    dobas_sor = DobasData([1,1,5,5,1])
    print(DobasErtekelo.ket_par(dobas_sor))
